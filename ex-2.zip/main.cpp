/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
   int a, d;
   printf(" digite um valor \n");
   scanf(" %d",&a);
   
   printf(" o dobro do valor digitado e \n");
   d=a*2;
   printf(" %d", d);
   
   
  
  
  
  
  
  

    return 0;
}
