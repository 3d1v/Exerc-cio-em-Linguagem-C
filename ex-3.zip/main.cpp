/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
       int a,b, s;
   printf(" digite o primeiro valor e o segundo valor  ");
  scanf("%d %d", &a, &b);
   s=a+b;
   
   printf(" o resultado da soma dos valores sao " );
   printf("%d", s);

    return 0;
}
