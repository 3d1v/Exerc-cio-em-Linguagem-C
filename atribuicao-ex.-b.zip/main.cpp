/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    int a,b,c;
  a=10;
  b=a+1;
  a=b+1;
  b=a+1;
  printf(" valor de A \n ");
  printf("%d",a );
  a=b+1;
  printf(" \n valor de B, C \n " );
  printf("%d %d ", a, b);
    
    

    return 0;
}
